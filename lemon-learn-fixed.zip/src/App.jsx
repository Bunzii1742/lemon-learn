import React from 'react'

export default function App() {
  return (
    <div className="min-h-screen bg-yellow-50 dark:bg-sky-900 text-gray-800 dark:text-slate-100 flex items-center justify-center">
      <h1 className="text-4xl font-bold text-yellow-500 dark:text-yellow-300">🍋 Lemon Learn is Live!</h1>
    </div>
  )
}
